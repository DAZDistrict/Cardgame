# Dra ut ur skärmen – PWA

Lägg upp hela mappen på valfri HTTPS-adress. Enklast och gratis: GitHub Pages.

1. Skapa ett nytt repo på github.com (t.ex. "draut"), ladda upp alla filer i mappen (index.html, sw.js, manifest.webmanifest, icons/).
2. Settings → Pages → Source: "Deploy from a branch", branch main, folder /(root). Spara.
3. Efter någon minut finns sidan på https://<ditt-användarnamn>.github.io/draut/
4. Öppna adressen i Chrome på S25 Ultra → ⋮ → "Installera app". Klart.

Efter installation fungerar appen offline och sparar inställningar/bilder lokalt i telefonen.
Vid ändringar i index.html: höj versionsnamnet i sw.js (draut-v1 → v2) så att telefonen hämtar nya filer.
